<?php return array (
  0 => 'App\\Endpoint\\Console\\CreateUserCommand',
  1 => 'App\\Endpoint\\Console\\DoNothing',
);