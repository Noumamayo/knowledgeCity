<?php

declare(strict_types=1);

namespace App\Entity;

use Cycle\Annotated\Annotation\Column;
use Cycle\Annotated\Annotation\Entity;
use Cycle\Annotated\Annotation\Relation\BelongsTo;
use Cycle\Annotated\Annotation\Relation\HasMany;

#[Entity(table: 'stores')]
class Store
{
    #[Column(type: 'bigPrimary', name: 'store_id')]
    private int $storeId;
    
    #[Column(type: 'bigInteger', name: 'region_id')]
    private int $regionId;
    
    #[Column(type: 'string', name: 'store_name')]
    private string $storeName;
    
    #[BelongsTo(target: Regions::class, innerKey: 'region_id', outerKey: 'region_id')]
    private Regions $region;
    
    #[HasMany(target: Order::class, innerKey: 'store_id', outerKey: 'store_id')]
    private array $orders;

    public function getStoreId(): int
    {
        return $this->storeId;
    }

    public function getRegionId(): int
    {
        return $this->regionId;
    }

    public function getStoreName(): string
    {
        return $this->storeName;
    }

    public function getRegion(): Regions
    {
        return $this->region;
    }

    public function getOrders(): array
    {
        return $this->orders;
    }

    public function toArray(): array
    {
        return [
            'store_id' => $this->storeId,
            'region_id' => $this->regionId,
            'store_name' => $this->storeName
        ];
    }
}