<?php

declare(strict_types=1);

namespace App\Entity;

use Cycle\Annotated\Annotation\Column;
use Cycle\Annotated\Annotation\Entity;
use Cycle\Annotated\Annotation\Relation\BelongsTo;
use Cycle\Annotated\Annotation\Relation\HasMany;

#[Entity(table: 'orders')]
class Order
{
    #[Column(type: 'bigPrimary', name: 'order_id')]
    private int $orderId;

    #[Column(type: 'bigInteger', name: 'store_id')]
    private int $storeId;

    #[Column(type: 'bigInteger', name: 'customer_id')]
    private int $customerId;

    #[Column(type: 'datetime', name: 'order_date')]
    private ?\DateTimeInterface $orderDate = null;

    #[Column(type: 'decimal', precision: 12, scale: 2, name: 'total_amount')]
    private float $totalAmount = 0.0;

    #[BelongsTo(target: Store::class, innerKey: 'store_id', outerKey: 'store_id')]
    private Store $store;

    #[HasMany(target: OrderItems::class, innerKey: 'order_id', outerKey: 'order_id')]
    private array $orderItems = [];

    public function __construct()
    {
        $this->orderDate = new \DateTime();
        $this->orderItems = [];
    }

    public function getOrderId(): int
    {
        return $this->orderId;
    }

    public function setOrderId(int $orderId): void
    {
        $this->orderId = $orderId;
    }

    public function getStoreId(): int
    {
        return $this->storeId;
    }

    public function setStoreId(int $storeId): void
    {
        $this->storeId = $storeId;
    }

    public function getCustomerId(): int
    {
        return $this->customerId;
    }

    public function setCustomerId(int $customerId): void
    {
        $this->customerId = $customerId;
    }

    public function getOrderDate(): ?\DateTimeInterface
    {
        return $this->orderDate;
    }

    public function setOrderDate(\DateTimeInterface $orderDate): void
    {
        $this->orderDate = $orderDate;
    }

    public function getTotalAmount(): float
    {
        return $this->totalAmount;
    }

    public function setTotalAmount(float $totalAmount): void
    {
        $this->totalAmount = $totalAmount;
    }

    public function getStore(): Store
    {
        return $this->store;
    }

    public function setStore(Store $store): void
    {
        $this->store = $store;
    }

    public function getOrderItems(): array
    {
        return $this->orderItems;
    }

    public function setOrderItems(array $orderItems): void
    {
        $this->orderItems = $orderItems;
    }

    public function toArray(): array
    {
        return [
            'order_id' => $this->orderId,
            'store_id' => $this->storeId,
            'customer_id' => $this->customerId,
            'order_date' => $this->orderDate ? $this->orderDate->format('Y-m-d H:i:s') : null,
            'total_amount' => $this->totalAmount
        ];
    }
}