<?php

declare(strict_types=1);

namespace App\Endpoint\Web;

use App\Service\ReportService;
use Spiral\Views\ViewsInterface;
use Spiral\Router\Annotation\Route;
use Spiral\Http\Request\InputManager;

/**
 * Controller responsible for handling report-related web requests.
 * Provides endpoints for various sales and order reports.
 */
class ReportController
{
    /**
     * @param ViewsInterface $views Service for rendering views
     * @param ReportService $reportService Service for generating reports
     * @param InputManager $input Service for handling request input
     */
    public function __construct(
        private readonly ViewsInterface $views,
        private readonly ReportService $reportService,
        private readonly InputManager $input
    ) {
    }

    /**
     * Renders the main dashboard with current month's sales data.
     * 
     * @return string Rendered HTML view
     */
    public function index(): string
    {
        try {
            // Set default date range to current month
            $startDate = date('Y-m-01');  // First day of current month
            $endDate = date('Y-m-t');     // Last day of current month
            
            // Get sales report data and render the dashboard view
            $viewData = $this->reportService->getMonthlySalesReport($startDate, $endDate);
            return $this->views->render('sales/dashboard', $viewData);
        } catch (\Exception $e) {
            // Log any errors and display generic error message
            error_log("Error in ReportController: " . $e->getMessage());
            return $this->views->render('error', ['message' => 'An error occurred while generating the report.']);
        }
    }

    /**
     * Displays monthly sales data broken down by region.
     * Allows date range filtering with defaults to last 12 months.
     * 
     * @return string Rendered HTML view
     */
    #[Route(route: '/monthly-sales-by-region', name: 'monthly-sales-by-region')]
    public function monthlySalesByRegion(): string
    {
        try {
            // Get date range from input or use defaults
            // Default end date is last day of current month
            $endDate = $this->input->input('endDate') ?: date('Y-m-t');
            // Default start date is first day of 11 months ago
            $startDate = $this->input->input('startDate') ?: date('Y-m-01', strtotime('-11 months', strtotime($endDate)));

            // Normalize dates to ensure consistent format
            // Always use last day of month for end date
            $endDate = date('Y-m-t', strtotime($endDate));
            // Always use first day of month for start date
            $startDate = date('Y-m-01', strtotime($startDate));
            
            // Process and aggregate sales data by region
            $processedData = $this->reportService->processRegionalSalesData($startDate, $endDate);
            
            // Render view with processed data and date range
            return $this->views->render('reports/monthlySalesByRegion', [
                'processedData' => $processedData,
                'startDate' => $startDate,
                'endDate' => $endDate
            ]);
        } catch (\Exception $e) {
            // Log any errors and display generic error message
            error_log("Error in monthlySalesByRegion: " . $e->getMessage());
            return $this->views->render('error', ['message' => 'An error occurred while generating the sales report.']);
        }
    }

    /**
     * Displays detailed order information for users.
     * Shows order history and related details.
     * 
     * @return string Rendered HTML view
     */
    public function userOrderDetails(): string
    {
        try {
            $orderDetails = $this->reportService->getUserOrderDetails();
            return $this->views->render('sales/orderDetails', ['orders' => $orderDetails]);
        } catch (\Exception $e) {
            error_log("Error in userOrderDetails: " . $e->getMessage());
            return $this->views->render('error', ['message' => 'An error occurred while retrieving order details.']);
        }
    }

    /**
     * Generates a report on data integrity.
     * Checks for data consistency and potential issues.
     * 
     * @return string Rendered HTML view
     */
    public function dataIntegrity(): string
    {
        try {
            $integrityData = $this->reportService->getDataIntegrityReport();
            return $this->views->render('sales/integrity', ['data' => $integrityData]);
        } catch (\Exception $e) {
            error_log("Error in dataIntegrity: " . $e->getMessage());
            return $this->views->render('error', ['message' => 'An error occurred while checking data integrity.']);
        }
    }

    /**
     * Displays top performing categories for each store with sales rankings.
     * Allows date range filtering with defaults to last 3 months.
     */
    #[Route(route: '/top-categories-by-store', name: 'top-categories-by-store')]
    public function topCategoriesByStore(): string
    {
        try {
            // Get date range from input or use defaults
            $endDate = $this->input->input('endDate') ?: date('Y-m-t');
            $startDate = $this->input->input('startDate') ?: date('Y-m-01', strtotime('-2 months', strtotime($endDate)));

            // Normalize dates
            $endDate = date('Y-m-t', strtotime($endDate));
            $startDate = date('Y-m-01', strtotime($startDate));
            
            // Get report data
            $reportData = $this->reportService->getTopCategoriesByStore($startDate, $endDate);
            
            try {
                return $this->views->render('reports/topCategoriesByStore', [
                    'data' => $reportData,
                    'startDate' => $startDate,
                    'endDate' => $endDate
                ]);
            } catch (\Throwable $e) {
                error_log("View not found - reports/topCategoriesByStore: " . $e->getMessage());
                throw new \RuntimeException('Report view template not found');
            }
        } catch (\Exception $e) {
            error_log("Error in topCategoriesByStore: " . $e->getMessage());
            error_log("Stack trace: " . $e->getTraceAsString());
            
            try {
                return $this->views->render('error', [
                    'message' => 'An error occurred while generating the categories report.',
                    'details' => $e->getMessage()
                ]);
            } catch (\Throwable $e2) {
                // If even the error view fails, return a plain text response
                error_log("Error view failed: " . $e2->getMessage());
                return 'An error occurred while generating the report. Please try again later.';
            }
        }
    }
}