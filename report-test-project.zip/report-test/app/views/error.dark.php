<extends:layout.base title="Error"/>

<block:content>
    <div class="container mx-auto px-4 py-8">
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
            <strong class="font-bold">Error!</strong>
            <span class="block sm:inline">{{$message}}</span>
            @if(isset($details))
                <div class="mt-2 text-sm">
                    <pre class="whitespace-pre-wrap">{{$details}}</pre>
                </div>
            @endif
        </div>
        <div class="mt-4">
            <a href="/" class="text-blue-500 hover:text-blue-700">Return to Home</a>
        </div>
    </div>
</block:content> 