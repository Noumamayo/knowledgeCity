<?php

declare(strict_types=1);

namespace Migration;

use Cycle\Migrations\Migration;

class OrmDefault6b37c029f83df5d5b93667bad89b5fc9 extends Migration
{
    protected const DATABASE = 'default';

    public function up(): void
    {
        $this
            ->table('users')
            ->addColumn('id', 'primary', ['nullable' => false])
            ->addColumn('username', 'string', ['nullable' => false])
            ->addColumn('email', 'string', ['nullable' => false])
            ->setPrimaryKeys(['id'])
            ->create();

        // Ensure fast lookups by enforcing uniqueness on email
        $this->table('users')
            ->addIndex(['email'], ['unique' => true])
            ->update();
    }

    public function down(): void
    {
        $this->table('users')->drop();
    }
}
