<?php

declare(strict_types=1);

namespace App\Repository;

use Cycle\ORM\EntityManagerInterface;
use Cycle\ORM\ORMInterface;
use App\Entity\Order;
use App\Entity\User;
use App\Entity\Store;
use App\Entity\Product;
use App\Entity\OrderItems;
use App\Entity\Regions;

class ReportRepository
{
    private readonly ORMInterface $orm;

    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        ORMInterface $orm
    ) {
        $this->orm = $orm;
    }

    public function getMonthlySalesByRegion(string $startDate, string $endDate): array
    {
        try {
            error_log("Getting sales for period: $startDate to $endDate");

            $select = $this->orm->getRepository(Order::class)
                ->select()
                ->load('store')
                ->load('store.region')
                ->where('order_date', '>=', $startDate)
                ->where('order_date', '<=', $endDate);

            $orders = $select->fetchAll();
            error_log("Total orders found: " . count($orders));

            // Initialize data structures
            $regionalData = [];
            $summary = [
                'total_sales' => 0.0,
                'total_orders' => 0,
                'avg_order_value' => 0.0
            ];

            error_log("Initial summary: " . json_encode($summary));

            foreach ($orders as $order) {
                error_log("Raw order data: " . json_encode([
                    'id' => $order->getOrderId(),
                    'amount' => $order->getTotalAmount(),
                    'date' => $order->getOrderDate() ? $order->getOrderDate()->format('Y-m-d') : 'null'
                ]));

                $totalAmount = (float)$order->getTotalAmount();
                
                $orderDate = $order->getOrderDate();
                if (!$orderDate) {
                    error_log("Skipping order " . $order->getOrderId() . " - No date");
                    continue;
                }

                $period = $orderDate->format('Y-m');
                $store = $order->getStore();
                $region = $store->getRegion();
                $regionId = $region->getRegionId();
                $regionName = $region->getRegionName();

                $key = $period . '-' . $regionId;
                if (!isset($regionalData[$key])) {
                    $regionalData[$key] = [
                        'period' => $period,
                        'year' => (int)$orderDate->format('Y'),
                        'month' => (int)$orderDate->format('m'),
                        'region_id' => $regionId,
                        'region_name' => $regionName,
                        'total_orders' => 0,
                        'total_sales' => 0.0,
                        'avg_order_value' => 0.0
                    ];
                }

                $regionalData[$key]['total_orders']++;
                $regionalData[$key]['total_sales'] += $totalAmount;

                $summary['total_orders']++;
                $summary['total_sales'] += $totalAmount;
            }

            // Calculate averages
            foreach ($regionalData as &$data) {
                if ($data['total_orders'] > 0) {
                    $data['avg_order_value'] = $data['total_sales'] / $data['total_orders'];
                }
            }

            if ($summary['total_orders'] > 0) {
                $summary['avg_order_value'] = $summary['total_sales'] / $summary['total_orders'];
            }

            return [
                'data' => array_values($regionalData),
                'summary' => $summary
            ];

        } catch (\Exception $e) {
            error_log("Error getting monthly sales: " . $e->getMessage());
            throw $e;
        }
    }

    public function getOrdersWithUserDetails(): array
    {
        try {
            $select = $this->orm->getRepository(Order::class)
                ->select()
                ->load('store')
                ->load('store.region')
                ->with('orderItems')
                ->with('orderItems.product');

            $orders = $select->fetchAll();

            $result = [];
            foreach ($orders as $order) {
                $orderData = $order->toArray();
                $store = $order->getStore();
                
                $orderData['store_name'] = $store->getStoreName();
                $orderData['region_name'] = $store->getRegion()->getRegionName();
                
                $orderItems = [];
                foreach ($order->getOrderItems() as $item) {
                    $orderItems[] = sprintf(
                        '%s (Qty: %d, Unit Price: $%.2f, Total: $%.2f)',
                        $item->getProduct()->getProductName(),
                        $item->getQuantity(),
                        $item->getUnitPrice(),
                        $item->getLineTotal()
                    );
                }
                $orderData['order_items'] = implode('; ', $orderItems);

                $result[] = $orderData;
            }

            error_log("Found " . count($result) . " orders");
            return $result;

        } catch (\Exception $e) {
            error_log("Error fetching orders: " . $e->getMessage());
            throw $e;
        }
    }

    public function checkDataIntegrity(): array
    {
        try {
            $orderCount = $this->orm->getRepository(Order::class)
                ->select()
                ->count();

            $userCount = $this->orm->getRepository(User::class)
                ->select()
                ->count();

            $orders = $this->orm->getRepository(Order::class)
                ->select()
                ->fetchAll();

            $customerIds = array_map(fn($order) => $order->getCustomerId(), $orders);
            
            return [
                'orders' => [
                    'total_orders' => $orderCount,
                    'unique_customers' => count(array_unique($customerIds)),
                    'min_customer_id' => min($customerIds),
                    'max_customer_id' => max($customerIds)
                ],
                'users' => [
                    'total_users' => $userCount
                ]
            ];

        } catch (\Exception $e) {
            error_log("Error checking data integrity: " . $e->getMessage());
            throw $e;
        }
    }

    public function getUsersWithOrderDetails(): array
    {
        try {
            $users = $this->orm->getRepository(User::class)
                ->select()
                ->load('orders')
                ->load('orders.orderItems')
                ->load('orders.orderItems.product')
                ->load('orders.store')
                ->load('orders.store.region')
                ->fetchAll();

            $result = [];
            foreach ($users as $user) {
                $userData = [
                    'user_id' => $user->getUserId(),
                    'name' => $user->getName(),
                    'email' => $user->getEmail(),
                    'phone' => $user->getPhone() ?? 'N/A',
                    'total_orders' => count($user->getOrders()),
                    'total_spent' => 0.0,
                    'orders' => []
                ];

                foreach ($user->getOrders() as $order) {
                    $orderData = [
                        'order_id' => $order->getOrderId(),
                        'order_date' => $order->getOrderDate()->format('Y-m-d H:i:s'),
                        'total_amount' => $order->getTotalAmount(),
                        'store' => [
                            'name' => $order->getStore()->getStoreName(),
                            'region' => $order->getStore()->getRegion()->getRegionName()
                        ],
                        'items' => []
                    ];

                    foreach ($order->getOrderItems() as $item) {
                        $orderData['items'][] = [
                            'product_name' => $item->getProduct()->getProductName(),
                            'quantity' => $item->getQuantity(),
                            'unit_price' => $item->getUnitPrice(),
                            'line_total' => $item->getLineTotal()
                        ];
                    }

                    $userData['total_spent'] += $order->getTotalAmount();
                    $userData['orders'][] = $orderData;
                }

                $result[] = $userData;
            }

            return $result;
        } catch (\Exception $e) {
            error_log("Error fetching users with order details: " . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Get top categories by store with sales data
     */
    public function getTopCategoriesByStore(string $startDate, string $endDate): array
    {
        try {
            $select = $this->orm->getRepository(Order::class)
                ->select()
                ->load('store')
                ->load('orderItems')
                ->load('orderItems.product')
                ->load('orderItems.product.category')
                ->where('order_date', '>=', $startDate)
                ->where('order_date', '<=', $endDate);

            $orders = $select->fetchAll();

            // Initialize data structure
            $salesByStoreCategory = [];
            
            // Process orders
            foreach ($orders as $order) {
                $storeId = $order->getStore()->getStoreId();
                $storeName = $order->getStore()->getStoreName();

                foreach ($order->getOrderItems() as $item) {
                    $categoryId = $item->getProduct()->getCategory()->getCategoryId();
                    $categoryName = $item->getProduct()->getCategory()->getCategoryName();
                    $salesAmount = $item->getQuantity() * $item->getUnitPrice();

                    $key = $storeId . '-' . $categoryId;
                    if (!isset($salesByStoreCategory[$key])) {
                        $salesByStoreCategory[$key] = [
                            'store_id' => $storeId,
                            'store_name' => $storeName,
                            'category_id' => $categoryId,
                            'category_name' => $categoryName,
                            'total_sales' => 0
                        ];
                    }
                    $salesByStoreCategory[$key]['total_sales'] += $salesAmount;
                }
            }

            // Calculate rankings for each store
            $storeRankings = [];
            foreach ($salesByStoreCategory as $key => $data) {
                $storeId = $data['store_id'];
                if (!isset($storeRankings[$storeId])) {
                    $storeRankings[$storeId] = [];
                }
                $storeRankings[$storeId][] = &$salesByStoreCategory[$key];
            }

            // Sort and assign rankings within each store
            foreach ($storeRankings as &$storeData) {
                usort($storeData, function($a, $b) {
                    return $b['total_sales'] <=> $a['total_sales'];
                });
                
                $rank = 1;
                foreach ($storeData as &$category) {
                    $category['rank'] = $rank++;
                }
            }

            return array_values($salesByStoreCategory);

        } catch (\Exception $e) {
            error_log("Error in getTopCategoriesByStore: " . $e->getMessage());
            throw $e;
        }
    }
} 