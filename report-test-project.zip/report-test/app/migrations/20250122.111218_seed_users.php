<?php

declare(strict_types=1);

namespace Migration;

use Cycle\Migrations\Migration;

class SeedUsers20250122111218 extends Migration
{
    protected const DATABASE = 'default';

    public function up(): void
    {
        // Generate 100 users to match the customer_id range in the sales data
        for ($i = 1; $i <= 100; $i++) {
            $this->database()->insert('users')->values([
                'id' => $i,
                'username' => "user{$i}",
                'email' => "user{$i}@example.com"
            ])->run();
        }
    }

    public function down(): void
    {
        $this->database()->delete('users')->run();
    }
} 