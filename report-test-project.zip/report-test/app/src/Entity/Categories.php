<?php

declare(strict_types=1);

namespace App\Entity;

use Cycle\Annotated\Annotation\Column;
use Cycle\Annotated\Annotation\Entity;
use Cycle\Annotated\Annotation\Relation\HasMany;

#[Entity(table: 'categories')]
class Categories
{
    #[Column(type: 'bigPrimary', name: 'category_id')]
    private int $categoryId;
    
    #[Column(type: 'string', name: 'category_name')]
    private string $categoryName;
    
    #[HasMany(target: Product::class, innerKey: 'category_id', outerKey: 'category_id')]
    private array $products = [];

    public function __construct()
    {
        $this->products = [];
    }

    public function getCategoryId(): int
    {
        return $this->categoryId;
    }

    public function getCategoryName(): string
    {
        return $this->categoryName;
    }

    public function getProducts(): array
    {
        return $this->products;
    }

    public function setProducts(array $products): void
    {
        $this->products = $products;
    }

    public function toArray(): array
    {
        return [
            'category_id' => $this->categoryId,
            'category_name' => $this->categoryName
        ];
    }
}
