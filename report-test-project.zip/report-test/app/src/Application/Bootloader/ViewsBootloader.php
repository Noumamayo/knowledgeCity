<?php

declare(strict_types=1);

namespace App\Application\Bootloader;

use Spiral\Boot\Bootloader\Bootloader;
use Spiral\Views\Config\ViewsConfig;

class ViewsBootloader extends Bootloader
{
    protected const SINGLETONS = [
        ViewsConfig::class => [self::class, 'viewsConfig'],
    ];

    protected function viewsConfig(): ViewsConfig
    {
        return new ViewsConfig([
            'cache' => directory('cache') . 'views',
            'namespaces' => [
                'default' => [
                    directory('views')
                ],
            ],
        ]);
    }
} 