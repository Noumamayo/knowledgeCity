<?php

declare(strict_types=1);

namespace App\Entity;

use Cycle\Annotated\Annotation\Column;
use Cycle\Annotated\Annotation\Entity;
use Cycle\Annotated\Annotation\Relation\HasMany;

#[Entity(table: 'regions')]
class Regions
{
    #[Column(type: 'bigPrimary', name: 'region_id')]
    private int $regionId;
    
    #[Column(type: 'string', name: 'region_name', length: 255)]
    private string $regionName;

    #[HasMany(target: Store::class, innerKey: 'region_id', outerKey: 'region_id')]
    private array $stores = [];

    public function __construct()
    {
        $this->stores = [];
    }

    public function getRegionId(): int
    {
        return $this->regionId;
    }

    public function setRegionId(int $regionId): void
    {
        $this->regionId = $regionId;
    }

    public function getRegionName(): string
    {
        return $this->regionName;
    }

    public function setRegionName(string $regionName): void
    {
        $this->regionName = $regionName;
    }

    public function getStores(): array
    {
        return $this->stores;
    }

    public function setStores(array $stores): void
    {
        $this->stores = $stores;
    }

    public function toArray(): array
    {
        return [
            'region_id' => $this->regionId,
            'region_name' => $this->regionName
        ];
    }
}
