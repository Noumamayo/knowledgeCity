<?php

declare(strict_types=1);

namespace App\Service;

use App\Repository\ReportRepository;

/**
 * Service class for generating various sales and data reports
 */
class ReportService
{
    /**
     * @param ReportRepository $reportRepository Repository for fetching report data
     */
    public function __construct(
        private readonly ReportRepository $reportRepository
    ) {
    }

    /**
     * Generates a monthly sales report for the given date range
     *
     * @param string $startDate Start date in Y-m-d format
     * @param string $endDate End date in Y-m-d format
     * @return array Report data containing sales figures and summary statistics
     * @throws \Exception If there is an error generating the report
     */
    public function getMonthlySalesReport(string $startDate, string $endDate): array
    {
        try {
            $salesData = $this->reportRepository->getMonthlySalesByRegion($startDate, $endDate);
            
            // Initialize summary data structure if not present
            if (!isset($salesData['summary'])) {
                $salesData['summary'] = [
                    'total_sales' => 0.0,
                    'total_orders' => 0,
                    'avg_order_value' => 0.0
                ];
            }

            // Format and return the sales data with summary statistics
            return [
                'salesData' => $salesData['data'] ?? [],
                'summary' => [
                    'total_sales' => number_format($salesData['summary']['total_sales'] ?? 0, 2),
                    'total_orders' => number_format($salesData['summary']['total_orders'] ?? 0),
                    'avg_order_value' => number_format($salesData['summary']['avg_order_value'] ?? 0, 2)
                ],
                'startDate' => $startDate,
                'endDate' => $endDate
            ];
        } catch (\Exception $e) {
            error_log("Error in ReportService: " . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Processes and aggregates sales data by region for the given date range
     *
     * @param string $startDate Start date in Y-m-d format
     * @param string $endDate End date in Y-m-d format
     * @return array Processed data containing period, region and sales information
     * @throws \Exception If there is an error processing the data
     */
    public function processRegionalSalesData(string $startDate, string $endDate): array
    {
        try {
            $salesData = $this->reportRepository->getMonthlySalesByRegion($startDate, $endDate);
            
            // Initialize data structure for view processing
            $processedData = [
                'periods' => [],          // Stores time period information
                'regions' => [],          // Maps region IDs to names
                'salesByRegion' => [],    // Sales amounts indexed by region and period
                'ordersByRegion' => [],   // Order counts indexed by region and period
                'summary' => [
                    'totalSales' => 0.0,
                    'totalOrders' => 0,
                    'avgOrderValue' => 0.0
                ]
            ];
            
            // Process each row of sales data
            if (isset($salesData['data']) && is_array($salesData['data'])) {
                foreach ($salesData['data'] as $row) {
                    $this->processRegionalDataRow($row, $processedData);
                }
            }
            
            // Calculate the average order value if there are orders
            if ($processedData['summary']['totalOrders'] > 0) {
                $processedData['summary']['avgOrderValue'] = 
                    $processedData['summary']['totalSales'] / $processedData['summary']['totalOrders'];
            }
            
            // Ensure periods are in chronological order
            ksort($processedData['periods']);
            
            return $processedData;
        } catch (\Exception $e) {
            error_log("Error processing regional sales data: " . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Processes a single row of regional sales data and updates the processed data array
     *
     * @param array $row Raw data row containing sales information
     * @param array $processedData Reference to the processed data array to update
     */
    private function processRegionalDataRow(array $row, array &$processedData): void
    {
        // Extract and convert sales figures
        $totalSales = isset($row['total_sales']) ? (float)$row['total_sales'] : 0.0;
        $totalOrders = isset($row['total_orders']) ? (int)$row['total_orders'] : 0;
        
        // Format period string (YYYY-MM)
        $period = sprintf('%d-%02d', $row['year'], $row['month']);
        
        // Store period information
        $processedData['periods'][$period] = [
            'year' => (int)$row['year'],
            'month' => (int)$row['month'],
            'label' => date('M Y', strtotime($period . '-01'))
        ];
        
        // Map region ID to name
        $processedData['regions'][$row['region_id']] = $row['region_name'];
        
        // Initialize arrays for region if not exists
        if (!isset($processedData['salesByRegion'][$row['region_id']])) {
            $processedData['salesByRegion'][$row['region_id']] = [];
        }
        if (!isset($processedData['ordersByRegion'][$row['region_id']])) {
            $processedData['ordersByRegion'][$row['region_id']] = [];
        }
        
        // Store sales and order data
        $processedData['salesByRegion'][$row['region_id']][$period] = $totalSales;
        $processedData['ordersByRegion'][$row['region_id']][$period] = $totalOrders;
        
        // Update summary totals
        $processedData['summary']['totalSales'] += $totalSales;
        $processedData['summary']['totalOrders'] += $totalOrders;
    }

    /**
     * Retrieves detailed order information for users
     *
     * @return array Order details with user information
     */
    public function getUserOrderDetails(): array
    {
        return $this->reportRepository->getOrdersWithUserDetails();
    }

    /**
     * Generates a report on data integrity and consistency
     *
     * @return array Data integrity check results
     */
    public function getDataIntegrityReport(): array
    {
        return $this->reportRepository->checkDataIntegrity();
    }

    /**
     * Get top performing categories by store with sales rankings
     */
    public function getTopCategoriesByStore(string $startDate, string $endDate): array
    {
        try {
            $data = $this->reportRepository->getTopCategoriesByStore($startDate, $endDate);
            
            // Process data for view
            $processedData = [
                'stores' => [],
                'summary' => [
                    'total_stores' => 0,
                    'total_sales' => 0,
                    'date_range' => [
                        'start' => $startDate,
                        'end' => $endDate
                    ]
                ]
            ];

            foreach ($data as $row) {
                $storeId = $row['store_id'];
                
                if (!isset($processedData['stores'][$storeId])) {
                    $processedData['stores'][$storeId] = [
                        'store_id' => $storeId,
                        'store_name' => $row['store_name'],
                        'categories' => [],
                        'total_sales' => 0
                    ];
                }

                $processedData['stores'][$storeId]['categories'][] = [
                    'category_name' => $row['category_name'],
                    'total_sales' => $row['total_sales'],
                    'rank' => $row['rank']
                ];

                $processedData['stores'][$storeId]['total_sales'] += $row['total_sales'];
                $processedData['summary']['total_sales'] += $row['total_sales'];
            }

            $processedData['summary']['total_stores'] = count($processedData['stores']);
            $processedData['stores'] = array_values($processedData['stores']);

            return $processedData;

        } catch (\Exception $e) {
            error_log("Error processing top categories data: " . $e->getMessage());
            throw $e;
        }
    }
} 