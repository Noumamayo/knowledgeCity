<extends:layout.base title="Monthly Sales By Region"/>

<stack:push name="styles">
    <link rel="stylesheet" href="/styles/welcome.css"/>
    <style>
        .min-h-screen{
            display: none !important;
        }
        .chart-container {
            padding: 20px;
            margin: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .filters {
            margin: 20px;
            padding: 20px;
            background: #f5f5f5;
            border-radius: 8px;
        }
        .summary-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin: 20px;
        }
        .summary-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .summary-card h3 {
            margin: 0 0 10px 0;
            color: #333;
        }
        .summary-value {
            font-size: 24px;
            font-weight: bold;
            color: #2c5282;
        }
        .table-container {
            margin: 20px;
            overflow-x: auto;
        }
        .data-table {
            width: 100%;
            border-collapse: collapse;
        }
        .data-table th, .data-table td {
            padding: 8px;
            border: 1px solid #ddd;
            text-align: right;
        }
        .data-table th {
            background: #f5f5f5;
        }
    </style>
</stack:push>

<define:body>
    <div class="container">
        <div style="display: flex; justify-content: space-between; align-items: center; margin: 20px;">
            <h1 class="main-title">Monthly Sales By Region</h1>
            <a href="/" class="btn btn-primary" style="background-color: #2563eb; color: white; padding: 10px 20px; border-radius: 6px; border: none; font-weight: 500; text-decoration: none; transition: all 0.2s ease; box-shadow: 0 2px 4px rgba(37,99,235,0.2);">Return to Home</a>
        </div>
        
        <div class="filters">
            <form id="dateRangeForm">
                <label for="startDate">Start Date:</label>
                <input type="date" id="startDate" value="{{$startDate}}">
                
                <label for="endDate">End Date:</label>
                <input type="date" id="endDate" value="{{$endDate}}">
                
                <button type="submit" class="btn btn-primary" style="background-color: #2563eb; color: white; padding: 10px 20px; border-radius: 6px; border: none; font-weight: 500; transition: all 0.2s ease; box-shadow: 0 2px 4px rgba(37,99,235,0.2); hover:background-color: #1d4ed8;">Update Report</button>
            </form>
        </div>

        <div class="summary-cards">
            <div class="summary-card">
                <h3>Total Sales</h3>
                <div class="summary-value">
                    ${{number_format($processedData['summary']['totalSales'], 2)}}
                </div>
            </div>
            <div class="summary-card">
                <h3>Total Orders</h3>
                <div class="summary-value">
                    {{number_format($processedData['summary']['totalOrders'])}}
                </div>
            </div>
            <div class="summary-card">
                <h3>Average Order Value</h3>
                <div class="summary-value">
                    ${{number_format($processedData['summary']['avgOrderValue'], 2)}}
                </div>
            </div>
        </div>

        <div class="chart-container">
            <canvas id="salesChart"></canvas>
        </div>
        
        <div class="chart-container">
            <canvas id="ordersChart"></canvas>
        </div>

        <div class="table-container">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Region</th>
                        @foreach($processedData['periods'] as $period => $periodData)
                            <th>{{$periodData['label']}}</th>
                        @endforeach
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($processedData['regions'] as $regionId => $regionName)
                        <tr>
                            <td>{{$regionName}}</td>
                            @php $regionTotal = 0; @endphp
                            @foreach($processedData['periods'] as $period => $periodData)
                                @php 
                                    $sales = $processedData['salesByRegion'][$regionId][$period] ?? 0;
                                    $regionTotal += $sales;
                                @endphp
                                <td>${{number_format($sales, 2)}}</td>
                            @endforeach
                            <td>${{number_format($regionTotal, 2)}}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</define:body>

<stack:push name="scripts">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Predefined color palette for better visibility
        const colorPalette = [
            '#2E86C1', // Blue
            '#E74C3C', // Red
            '#2ECC71', // Green
            '#F39C12', // Orange
            '#9B59B6', // Purple
            '#1ABC9C', // Turquoise
            '#D35400', // Dark Orange
            '#34495E', // Navy Blue
            '#27AE60', // Emerald
            '#E67E22'  // Carrot Orange
        ];

        // Process data for charts
        const processChartData = (data, valueKey) => {
            const periods = @json($processedData['periods']);
            const regions = @json($processedData['regions']);
            const salesByRegion = @json($processedData['salesByRegion']);
            const ordersByRegion = @json($processedData['ordersByRegion']);
            
            const labels = Object.values(periods).map(period => period.label);
            const datasets = Object.entries(regions).map(([regionId, regionName], index) => {
                const color = colorPalette[index % colorPalette.length];
                const values = Object.keys(periods).map(period => {
                    return valueKey === 'sales' 
                        ? (salesByRegion[regionId]?.[period] || 0)
                        : (ordersByRegion[regionId]?.[period] || 0);
                });
                
                return {
                    label: regionName,
                    data: values,
                    borderWidth: 2,
                    fill: valueKey === 'orders',
                    tension: 0.4,
                    borderColor: color,
                    backgroundColor: valueKey === 'orders' ? color : 'transparent'
                };
            });
            
            return { labels, datasets };
        };

        // Create Sales Chart
        const createSalesChart = () => {
            const ctx = document.getElementById('salesChart').getContext('2d');
            const chartData = processChartData(null, 'sales');
            
            new Chart(ctx, {
                type: 'line',
                data: chartData,
                options: {
                    responsive: true,
                    plugins: {
                        title: {
                            display: true,
                            text: 'Monthly Sales by Region',
                            font: { size: 16 }
                        },
                        legend: {
                            position: 'bottom'
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Sales Amount ($)'
                            }
                        }
                    }
                }
            });
        };

        // Create Orders Chart
        const createOrdersChart = () => {
            const ctx = document.getElementById('ordersChart').getContext('2d');
            const chartData = processChartData(null, 'orders');
            
            new Chart(ctx, {
                type: 'bar',
                data: chartData,
                options: {
                    responsive: true,
                    plugins: {
                        title: {
                            display: true,
                            text: 'Number of Orders by Region',
                            font: { size: 16 }
                        },
                        legend: {
                            position: 'bottom'
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Number of Orders'
                            }
                        }
                    }
                }
            });
        };

        // Initialize charts
        document.addEventListener('DOMContentLoaded', () => {
            createSalesChart();
            createOrdersChart();
            
            // Handle date range form submission
            document.getElementById('dateRangeForm').addEventListener('submit', async (e) => {
                e.preventDefault();
                const startDate = document.getElementById('startDate').value || '';
                const endDate = document.getElementById('endDate').value || '';
                
                if (!startDate || !endDate) {
                    alert('Please select both start and end dates');
                    return;
                }
                
                if (startDate > endDate) {
                    alert('Start date must be before or equal to end date');
                    return;
                }
                
                // Reload page with new date range
                window.location.href = `/monthly-sales-by-region?startDate=${encodeURIComponent(startDate)}&endDate=${encodeURIComponent(endDate)}`;
            });
        });
    </script>
</stack:push>
