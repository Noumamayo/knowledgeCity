<?php return array (
  'user' => 
  array (
    1 => 'App\\Domain\\User\\Entity\\User',
    2 => 'Cycle\\ORM\\Mapper\\Mapper',
    3 => 'Cycle\\ORM\\Select\\Source',
    4 => 'App\\Infrastructure\\Persistence\\CycleORMUserRepository',
    5 => 'default',
    6 => 'users',
    7 => 
    array (
      0 => 'id',
    ),
    8 => 
    array (
      0 => 'id',
    ),
    9 => 
    array (
      'id' => 'id',
      'username' => 'username',
      'email' => 'email',
    ),
    10 => 
    array (
    ),
    12 => NULL,
    13 => 
    array (
      'id' => 'int',
      'username' => 'string',
      'email' => 'string',
    ),
    14 => 
    array (
    ),
    19 => NULL,
    20 => 
    array (
      'id' => 2,
    ),
  ),
  'categories' => 
  array (
    1 => 'App\\Entity\\Categories',
    2 => 'Cycle\\ORM\\Mapper\\Mapper',
    3 => 'Cycle\\ORM\\Select\\Source',
    4 => 'Cycle\\ORM\\Select\\Repository',
    5 => 'default',
    6 => 'categories',
    7 => 
    array (
      0 => 'categoryId',
    ),
    8 => 
    array (
      0 => 'categoryId',
    ),
    9 => 
    array (
      'categoryId' => 'category_id',
      'categoryName' => 'category_name',
    ),
    10 => 
    array (
      'products' => 
      array (
        0 => 11,
        1 => 'product',
        3 => 10,
        2 => 
        array (
          30 => true,
          31 => false,
          41 => 
          array (
          ),
          42 => 
          array (
          ),
          33 => 
          array (
            0 => 'categoryId',
          ),
          32 => 
          array (
            0 => 'categoryId',
          ),
          4 => NULL,
        ),
      ),
    ),
    12 => NULL,
    13 => 
    array (
      'categoryId' => 'int',
      'categoryName' => 'string',
    ),
    14 => 
    array (
    ),
    19 => NULL,
    20 => 
    array (
      'categoryId' => 2,
    ),
  ),
  'order' => 
  array (
    1 => 'App\\Entity\\Order',
    2 => 'Cycle\\ORM\\Mapper\\Mapper',
    3 => 'Cycle\\ORM\\Select\\Source',
    4 => 'Cycle\\ORM\\Select\\Repository',
    5 => 'default',
    6 => 'orders',
    7 => 
    array (
      0 => 'orderId',
    ),
    8 => 
    array (
      0 => 'orderId',
    ),
    9 => 
    array (
      'orderId' => 'order_id',
      'storeId' => 'store_id',
      'customerId' => 'customer_id',
      'orderDate' => 'order_date',
      'totalAmount' => 'total_amount',
    ),
    10 => 
    array (
      'store' => 
      array (
        0 => 12,
        1 => 'store',
        3 => 10,
        2 => 
        array (
          30 => true,
          31 => false,
          33 => 
          array (
            0 => 'storeId',
          ),
          32 => 
          array (
            0 => 'storeId',
          ),
        ),
      ),
      'orderItems' => 
      array (
        0 => 11,
        1 => 'orderItems',
        3 => 10,
        2 => 
        array (
          30 => true,
          31 => false,
          41 => 
          array (
          ),
          42 => 
          array (
          ),
          33 => 
          array (
            0 => 'orderId',
          ),
          32 => 
          array (
            0 => 'orderId',
          ),
          4 => NULL,
        ),
      ),
    ),
    12 => NULL,
    13 => 
    array (
      'orderId' => 'int',
      'storeId' => 'int',
      'customerId' => 'int',
      'orderDate' => 'datetime',
      'totalAmount' => 'float',
    ),
    14 => 
    array (
    ),
    19 => NULL,
    20 => 
    array (
      'orderId' => 2,
    ),
  ),
  'orderItems' => 
  array (
    1 => 'App\\Entity\\OrderItems',
    2 => 'Cycle\\ORM\\Mapper\\Mapper',
    3 => 'Cycle\\ORM\\Select\\Source',
    4 => 'Cycle\\ORM\\Select\\Repository',
    5 => 'default',
    6 => 'order_items',
    7 => 
    array (
      0 => 'orderItemId',
    ),
    8 => 
    array (
      0 => 'orderItemId',
    ),
    9 => 
    array (
      'orderItemId' => 'order_item_id',
      'orderId' => 'order_id',
      'productId' => 'product_id',
      'quantity' => 'quantity',
      'unitPrice' => 'unit_price',
      'lineTotal' => 'line_total',
    ),
    10 => 
    array (
      'order' => 
      array (
        0 => 12,
        1 => 'order',
        3 => 10,
        2 => 
        array (
          30 => true,
          31 => false,
          33 => 
          array (
            0 => 'orderId',
          ),
          32 => 
          array (
            0 => 'orderId',
          ),
        ),
      ),
      'product' => 
      array (
        0 => 12,
        1 => 'product',
        3 => 10,
        2 => 
        array (
          30 => true,
          31 => false,
          33 => 
          array (
            0 => 'productId',
          ),
          32 => 
          array (
            0 => 'productId',
          ),
        ),
      ),
    ),
    12 => NULL,
    13 => 
    array (
      'orderItemId' => 'int',
      'orderId' => 'int',
      'productId' => 'int',
      'quantity' => 'int',
      'unitPrice' => 'float',
      'lineTotal' => 'float',
    ),
    14 => 
    array (
    ),
    19 => NULL,
    20 => 
    array (
      'orderItemId' => 2,
    ),
  ),
  'product' => 
  array (
    1 => 'App\\Entity\\Product',
    2 => 'Cycle\\ORM\\Mapper\\Mapper',
    3 => 'Cycle\\ORM\\Select\\Source',
    4 => 'Cycle\\ORM\\Select\\Repository',
    5 => 'default',
    6 => 'products',
    7 => 
    array (
      0 => 'productId',
    ),
    8 => 
    array (
      0 => 'productId',
    ),
    9 => 
    array (
      'productId' => 'product_id',
      'categoryId' => 'category_id',
      'productName' => 'product_name',
      'basePrice' => 'base_price',
    ),
    10 => 
    array (
      'category' => 
      array (
        0 => 12,
        1 => 'categories',
        3 => 10,
        2 => 
        array (
          30 => true,
          31 => false,
          33 => 
          array (
            0 => 'categoryId',
          ),
          32 => 
          array (
            0 => 'categoryId',
          ),
        ),
      ),
      'orderItems' => 
      array (
        0 => 11,
        1 => 'orderItems',
        3 => 10,
        2 => 
        array (
          30 => true,
          31 => false,
          41 => 
          array (
          ),
          42 => 
          array (
          ),
          33 => 
          array (
            0 => 'productId',
          ),
          32 => 
          array (
            0 => 'productId',
          ),
          4 => NULL,
        ),
      ),
    ),
    12 => NULL,
    13 => 
    array (
      'productId' => 'int',
      'categoryId' => 'int',
      'productName' => 'string',
      'basePrice' => 'float',
    ),
    14 => 
    array (
    ),
    19 => NULL,
    20 => 
    array (
      'productId' => 2,
    ),
  ),
  'regions' => 
  array (
    1 => 'App\\Entity\\Regions',
    2 => 'Cycle\\ORM\\Mapper\\Mapper',
    3 => 'Cycle\\ORM\\Select\\Source',
    4 => 'Cycle\\ORM\\Select\\Repository',
    5 => 'default',
    6 => 'regions',
    7 => 
    array (
      0 => 'regionId',
    ),
    8 => 
    array (
      0 => 'regionId',
    ),
    9 => 
    array (
      'regionId' => 'region_id',
      'regionName' => 'region_name',
    ),
    10 => 
    array (
      'stores' => 
      array (
        0 => 11,
        1 => 'store',
        3 => 10,
        2 => 
        array (
          30 => true,
          31 => false,
          41 => 
          array (
          ),
          42 => 
          array (
          ),
          33 => 
          array (
            0 => 'regionId',
          ),
          32 => 
          array (
            0 => 'regionId',
          ),
          4 => NULL,
        ),
      ),
    ),
    12 => NULL,
    13 => 
    array (
      'regionId' => 'int',
      'regionName' => 'string',
    ),
    14 => 
    array (
    ),
    19 => NULL,
    20 => 
    array (
      'regionId' => 2,
    ),
  ),
  'store' => 
  array (
    1 => 'App\\Entity\\Store',
    2 => 'Cycle\\ORM\\Mapper\\Mapper',
    3 => 'Cycle\\ORM\\Select\\Source',
    4 => 'Cycle\\ORM\\Select\\Repository',
    5 => 'default',
    6 => 'stores',
    7 => 
    array (
      0 => 'storeId',
    ),
    8 => 
    array (
      0 => 'storeId',
    ),
    9 => 
    array (
      'storeId' => 'store_id',
      'regionId' => 'region_id',
      'storeName' => 'store_name',
    ),
    10 => 
    array (
      'region' => 
      array (
        0 => 12,
        1 => 'regions',
        3 => 10,
        2 => 
        array (
          30 => true,
          31 => false,
          33 => 
          array (
            0 => 'regionId',
          ),
          32 => 
          array (
            0 => 'regionId',
          ),
        ),
      ),
      'orders' => 
      array (
        0 => 11,
        1 => 'order',
        3 => 10,
        2 => 
        array (
          30 => true,
          31 => false,
          41 => 
          array (
          ),
          42 => 
          array (
          ),
          33 => 
          array (
            0 => 'storeId',
          ),
          32 => 
          array (
            0 => 'storeId',
          ),
          4 => NULL,
        ),
      ),
    ),
    12 => NULL,
    13 => 
    array (
      'storeId' => 'int',
      'regionId' => 'int',
      'storeName' => 'string',
    ),
    14 => 
    array (
    ),
    19 => NULL,
    20 => 
    array (
      'storeId' => 2,
    ),
  ),
);