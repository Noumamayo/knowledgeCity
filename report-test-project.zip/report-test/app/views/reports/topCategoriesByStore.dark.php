<extends:layout.base title="Top Categories by Store"/>

<block:content>
    <div class="container mx-auto px-4 py-8">
        <div class="flex justify-between items-center mb-6">
            <h1 class="text-2xl font-bold">Top Categories by Store</h1>
            <a href="/" class="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition-colors">
                Return to Home
            </a>
        </div>
        
        <!-- Date Range Filter -->
        <form method="GET" class="mb-8">
            <div class="flex gap-4">
                <div>
                    <label for="startDate" class="block text-sm font-medium text-gray-700">Start Date</label>
                    <input type="month" id="startDate" name="startDate" 
                           value="{{date('Y-m', strtotime($startDate))}}" 
                           class="mt-1 block rounded-md border-gray-300 shadow-sm">
                </div>
                <div>
                    <label for="endDate" class="block text-sm font-medium text-gray-700">End Date</label>
                    <input type="month" id="endDate" name="endDate" 
                           value="{{date('Y-m', strtotime($endDate))}}" 
                           class="mt-1 block rounded-md border-gray-300 shadow-sm">
                </div>
                <div class="flex items-end">
                    <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded-md">
                        Apply Filter
                    </button>
                </div>
            </div>
        </form>

        <!-- Summary -->
        <div class="bg-gray-50 p-4 rounded-lg mb-8">
            <h2 class="text-lg font-semibold mb-2">Summary</h2>
            <div class="grid grid-cols-3 gap-4">
                <div>
                    <span class="text-gray-600">Total Stores:</span>
                    <span class="font-semibold">{{$data['summary']['total_stores']}}</span>
                </div>
                <div>
                    <span class="text-gray-600">Total Sales:</span>
                    <span class="font-semibold">${{number_format($data['summary']['total_sales'], 2)}}</span>
                </div>
                <div>
                    <span class="text-gray-600">Period:</span>
                    <span class="font-semibold">{{date('M Y', strtotime($startDate))}} - {{date('M Y', strtotime($endDate))}}</span>
                </div>
            </div>
        </div>

        <!-- Store Data -->
        @foreach($data['stores'] as $store)
            <div class="mb-8">
                <h2 class="text-xl font-semibold mb-4">
                    {{$store['store_name']}}
                    <span class="text-gray-500 text-sm">
                        (Total: ${{number_format($store['total_sales'], 2)}})
                    </span>
                </h2>
                
                <table class="min-w-full bg-white border border-gray-300">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 border-b text-left">Rank</th>
                            <th class="px-6 py-3 border-b text-left">Category</th>
                            <th class="px-6 py-3 border-b text-right">Sales Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($store['categories'] as $category)
                            <tr>
                                <td class="px-6 py-4 border-b">{{$category['rank']}}</td>
                                <td class="px-6 py-4 border-b">{{$category['category_name']}}</td>
                                <td class="px-6 py-4 border-b text-right">
                                    ${{number_format($category['total_sales'], 2)}}
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @endforeach
    </div>
</block:content> 