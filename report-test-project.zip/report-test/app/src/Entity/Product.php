<?php

declare(strict_types=1);

namespace App\Entity;

use Cycle\Annotated\Annotation\Column;
use Cycle\Annotated\Annotation\Entity;
use Cycle\Annotated\Annotation\Relation\BelongsTo;
use Cycle\Annotated\Annotation\Relation\HasMany;

#[Entity(table: 'products')]
class Product
{
    #[Column(type: 'bigPrimary', name: 'product_id')]
    private int $productId;
    
    #[Column(type: 'bigInteger', name: 'category_id')]
    private int $categoryId;
    
    #[Column(type: 'string', name: 'product_name')]
    private string $productName;
    
    #[Column(type: 'decimal', precision: 10, scale: 2, name: 'base_price')]
    private float $basePrice;
    
    #[BelongsTo(target: Categories::class, innerKey: 'category_id', outerKey: 'category_id')]
    private Categories $category;
    
    #[HasMany(target: OrderItems::class, innerKey: 'product_id', outerKey: 'product_id')]
    private array $orderItems;

    public function getProductId(): int
    {
        return $this->productId;
    }

    public function getCategoryId(): int
    {
        return $this->categoryId;
    }

    public function getProductName(): string
    {
        return $this->productName;
    }

    public function getBasePrice(): float
    {
        return $this->basePrice;
    }

    public function getCategory(): Categories
    {
        return $this->category;
    }

    public function getOrderItems(): array
    {
        return $this->orderItems;
    }

    public function toArray(): array
    {
        return [
            'product_id' => $this->productId,
            'category_id' => $this->categoryId,
            'product_name' => $this->productName,
            'base_price' => $this->basePrice
        ];
    }
}