<?php

declare(strict_types=1);

namespace Migration;

use Cycle\Migrations\Migration;

class OrmDefaultBaea8475f53fb941e7457e8d11dbd0ef extends Migration
{
    protected const DATABASE = 'default';

    public function up(): void
    {
        // Create regions table
        $this->table('regions')
            ->addColumn('region_id', 'bigPrimary', ['nullable' => false])
            ->addColumn('region_name', 'string', ['nullable' => false, 'length' => 100])
            ->setPrimaryKeys(['region_id'])
            ->create();

        // Create stores table with region relationship
        $this->table('stores')
            ->addColumn('store_id', 'bigPrimary', ['nullable' => false])
            ->addColumn('region_id', 'bigInteger', ['nullable' => false])
            ->addColumn('store_name', 'string', ['nullable' => false, 'length' => 200])
            ->setPrimaryKeys(['store_id'])
            ->addIndex(['region_id'], ['name' => 'idx_stores_region'])
            ->addForeignKey(['region_id'], 'regions', ['region_id'], [
                'name' => 'fk_stores_region',
                'delete' => 'RESTRICT',
                'update' => 'CASCADE'
            ])
            ->create();

        // Create categories table
        $this->table('categories')
            ->addColumn('category_id', 'bigPrimary', ['nullable' => false])
            ->addColumn('category_name', 'string', ['nullable' => false, 'length' => 100])
            ->setPrimaryKeys(['category_id'])
            ->create();

        // Create products table with category relationship
        $this->table('products')
            ->addColumn('product_id', 'bigPrimary', ['nullable' => false])
            ->addColumn('category_id', 'bigInteger', ['nullable' => false])
            ->addColumn('product_name', 'string', ['nullable' => false, 'length' => 200])
            ->addColumn('base_price', 'decimal', ['nullable' => false, 'precision' => 10, 'scale' => 2])
            ->setPrimaryKeys(['product_id'])
            ->addIndex(['category_id'], ['name' => 'idx_products_category'])
            ->addForeignKey(['category_id'], 'categories', ['category_id'], [
                'name' => 'fk_products_category',
                'delete' => 'RESTRICT',
                'update' => 'CASCADE'
            ])
            ->create();

        // Create orders table (header)
        $this->table('orders')
            ->addColumn('order_id', 'bigPrimary', ['nullable' => false])
            ->addColumn('store_id', 'bigInteger', ['nullable' => false])
            ->addColumn('customer_id', 'bigInteger', ['nullable' => false])
            ->addColumn('order_date', 'datetime', ['nullable' => false])
            ->addColumn('total_amount', 'decimal', ['nullable' => false, 'precision' => 12, 'scale' => 2])
            ->setPrimaryKeys(['order_id'])
            ->addIndex(['store_id'], ['name' => 'idx_orders_store'])
            ->addIndex(['customer_id'], ['name' => 'idx_orders_customer'])
            ->addIndex(['order_date'], ['name' => 'idx_orders_date'])
            ->addForeignKey(['store_id'], 'stores', ['store_id'], [
                'name' => 'fk_orders_store',
                'delete' => 'RESTRICT',
                'update' => 'CASCADE'
            ])
            ->create();

        // Create order_items table (details)
        $this->table('order_items')
            ->addColumn('order_item_id', 'bigPrimary', ['nullable' => false])
            ->addColumn('order_id', 'bigInteger', ['nullable' => false])
            ->addColumn('product_id', 'bigInteger', ['nullable' => false])
            ->addColumn('quantity', 'integer', ['nullable' => false])
            ->addColumn('unit_price', 'decimal', ['nullable' => false, 'precision' => 10, 'scale' => 2])
            ->addColumn('line_total', 'decimal', ['nullable' => false, 'precision' => 12, 'scale' => 2])
            ->setPrimaryKeys(['order_item_id'])
            ->addIndex(['order_id'], ['name' => 'idx_order_items_order'])
            ->addIndex(['product_id'], ['name' => 'idx_order_items_product'])
            ->addForeignKey(['order_id'], 'orders', ['order_id'], [
                'name' => 'fk_order_items_order',
                'delete' => 'CASCADE',
                'update' => 'CASCADE'
            ])
            ->addForeignKey(['product_id'], 'products', ['product_id'], [
                'name' => 'fk_order_items_product',
                'delete' => 'RESTRICT',
                'update' => 'CASCADE'
            ])
            ->create();
    }

    public function down(): void
    {
        $this->table('order_items')->drop();
        $this->table('orders')->drop();
        $this->table('products')->drop();
        $this->table('categories')->drop();
        $this->table('stores')->drop();
        $this->table('regions')->drop();
    }
}
