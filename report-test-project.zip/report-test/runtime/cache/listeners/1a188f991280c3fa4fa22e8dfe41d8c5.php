<?php return array (
  0 => 'App\\Endpoint\\Web\\Api',
  1 => 'App\\Endpoint\\Web\\CurrentDateController',
  2 => 'App\\Endpoint\\Web\\HomeController',
  3 => 'App\\Endpoint\\Web\\ReportController',
);