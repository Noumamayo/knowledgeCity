<?php

declare(strict_types=1);

namespace App\Entity;

use Cycle\Annotated\Annotation\Column;
use Cycle\Annotated\Annotation\Entity;
use Cycle\Annotated\Annotation\Relation\BelongsTo;

#[Entity(table: 'order_items')]
class OrderItems
{
    #[Column(type: 'bigPrimary', name: 'order_item_id')]
    private int $orderItemId;

    #[Column(type: 'bigInteger', name: 'order_id')]
    private int $orderId;

    #[Column(type: 'bigInteger', name: 'product_id')]
    private int $productId;

    #[Column(type: 'integer', name: 'quantity')]
    private int $quantity;

    #[Column(type: 'decimal', precision: 10, scale: 2, name: 'unit_price')]
    private float $unitPrice;

    #[Column(type: 'decimal', precision: 12, scale: 2, name: 'line_total')]
    private float $lineTotal;

    #[BelongsTo(target: Order::class, innerKey: 'order_id', outerKey: 'order_id')]
    private Order $order;

    #[BelongsTo(target: Product::class, innerKey: 'product_id', outerKey: 'product_id')]
    private Product $product;

    public function getOrderItemId(): int
    {
        return $this->orderItemId;
    }

    public function getOrderId(): int
    {
        return $this->orderId;
    }

    public function getProductId(): int
    {
        return $this->productId;
    }

    public function getQuantity(): int
    {
        return $this->quantity;
    }

    public function getUnitPrice(): float
    {
        return $this->unitPrice;
    }

    public function getLineTotal(): float
    {
        return $this->lineTotal;
    }

    public function getOrder(): Order
    {
        return $this->order;
    }

    public function getProduct(): Product
    {
        return $this->product;
    }

    public function toArray(): array
    {
        return [
            'orderItemId' => $this->orderItemId,
            'orderId' => $this->orderId,
            'productId' => $this->productId,
            'quantity' => $this->quantity,
            'unitPrice' => $this->unitPrice,
            'lineTotal' => $this->lineTotal
        ];
    }
}
