<extends:layout.base title="User Listing"/>

<block:content>
    <div class="container mx-auto px-4 py-8">
        <div class="mb-8">
            <h1 class="text-3xl font-bold mb-4">User Listing</h1>
            <div class="grid grid-cols-2 gap-4 bg-gray-100 p-4 rounded">
                <div>
                    <span class="font-bold">Total Users:</span> {{ $totalUsers }}
                </div>
                <div>
                    <span class="font-bold">Total Orders:</span> {{ $totalOrders }}
                </div>
            </div>
        </div>

        <div class="space-y-8">
            @foreach($users as $user)
            <div class="border rounded-lg shadow-lg p-6 bg-white">
                <div class="mb-4 border-b pb-4">
                    <h2 class="text-2xl font-bold mb-2">{{ $user['name'] }}</h2>
                    <div class="grid grid-cols-3 gap-4">
                        <div>
                            <span class="font-semibold">Email:</span> {{ $user['email'] }}
                        </div>
                        <div>
                            <span class="font-semibold">Phone:</span> {{ $user['phone'] }}
                        </div>
                        <div>
                            <span class="font-semibold">Total Spent:</span> ${{ number_format($user['total_spent'], 2) }}
                        </div>
                    </div>
                </div>

                <div class="mb-4">
                    <h3 class="text-xl font-semibold mb-2">Orders ({{ count($user['orders']) }})</h3>
                    @foreach($user['orders'] as $order)
                    <div class="border rounded p-4 mb-4">
                        <div class="grid grid-cols-4 gap-4 mb-2">
                            <div>
                                <span class="font-semibold">Order ID:</span> #{{ $order['order_id'] }}
                            </div>
                            <div>
                                <span class="font-semibold">Date:</span> {{ $order['order_date'] }}
                            </div>
                            <div>
                                <span class="font-semibold">Store:</span> {{ $order['store']['name'] }}
                            </div>
                            <div>
                                <span class="font-semibold">Region:</span> {{ $order['store']['region'] }}
                            </div>
                        </div>

                        <table class="w-full">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-4 py-2 text-left">Product</th>
                                    <th class="px-4 py-2 text-right">Quantity</th>
                                    <th class="px-4 py-2 text-right">Unit Price</th>
                                    <th class="px-4 py-2 text-right">Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($order['items'] as $item)
                                <tr class="border-t">
                                    <td class="px-4 py-2">{{ $item['product_name'] }}</td>
                                    <td class="px-4 py-2 text-right">{{ $item['quantity'] }}</td>
                                    <td class="px-4 py-2 text-right">${{ number_format($item['unit_price'], 2) }}</td>
                                    <td class="px-4 py-2 text-right">${{ number_format($item['line_total'], 2) }}</td>
                                </tr>
                                @endforeach
                                <tr class="border-t font-bold">
                                    <td colspan="3" class="px-4 py-2 text-right">Order Total:</td>
                                    <td class="px-4 py-2 text-right">${{ number_format($order['total_amount'], 2) }}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    @endforeach
                </div>
            </div>
            @endforeach
        </div>
    </div>
</block:content> 