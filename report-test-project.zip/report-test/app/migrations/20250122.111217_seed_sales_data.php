<?php

declare(strict_types=1);

namespace Migration;

use Cycle\Migrations\Migration;

class SeedSalesData20250122111217 extends Migration
{
    protected const DATABASE = 'default';

    public function up(): void
    {
        // First, clear all existing data
        $this->down();
        
        echo "Starting data seeding process...\n";

        // Seed initial data (regions, stores, categories, products)
        $this->seedInitialData();
        
        // Process orders month by month
        $this->processOrdersByMonth();
        
        echo "Completed data seeding process.\n";
    }

    private function seedInitialData(): void
    {
        // 1. First seed regions (as it's the parent table)
        $regions = [
            ['region_id' => 1, 'region_name' => 'North'],
            ['region_id' => 2, 'region_name' => 'South'],
            ['region_id' => 3, 'region_name' => 'East'],
            ['region_id' => 4, 'region_name' => 'West'],
        ];
        
        foreach ($regions as $region) {
            $this->database()->insert('regions')
                ->values($region)
                ->run();
        }

        // 2. Then seed stores (depends on regions)
        $storeId = 1;
        foreach ($regions as $region) {
            for ($i = 1; $i <= 3; $i++) {
                $this->database()->insert('stores')->values([
                    'store_id' => $storeId,
                    'region_id' => $region['region_id'],
                    'store_name' => "{$region['region_name']} Store {$i}"
                ])->run();
                $storeId++;
            }
        }

        // 3. Seed categories (independent table)
        $categories = [
            ['category_id' => 1, 'category_name' => 'Electronics'],
            ['category_id' => 2, 'category_name' => 'Clothing'],
            ['category_id' => 3, 'category_name' => 'Food'],
            ['category_id' => 4, 'category_name' => 'Books'],
            ['category_id' => 5, 'category_name' => 'Home & Garden']
        ];

        foreach ($categories as $category) {
            $this->database()->insert('categories')
                ->values($category)
                ->run();
        }

        // 4. Seed products (depends on categories)
        $productId = 1;
        foreach ($categories as $category) {
            for ($i = 1; $i <= 5; $i++) {
                $price = mt_rand(10, 1000) / 10; // Generate price between 1.0 and 100.0
                $this->database()->insert('products')->values([
                    'product_id' => $productId,
                    'category_id' => $category['category_id'],
                    'product_name' => "{$category['category_name']} Product {$i}",
                    'base_price' => $price
                ])->run();
                $productId++;
            }
        }
    }

    private function processOrdersByMonth(): void
    {
        $orderId = 1;
        $orderItemId = 1;
        $totalOrdersCreated = 0;

        try {
            for ($year = 2024; $year <= 2025; $year++) {
                $monthStart = 1;
                $monthEnd = ($year == 2025) ? 2 : 12;
                
                for ($month = $monthStart; $month <= $monthEnd; $month++) {
                    // Get all days in the month
                    $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $month, $year);
                    
                    // Create one order per day
                    for ($day = 1; $day <= $daysInMonth; $day++) {
                        // Create timestamp for current day at random business hour
                        $hour = mt_rand(8, 20);
                        $orderDate = sprintf('%04d-%02d-%02d %02d:%02d:%02d',
                            $year, $month, $day, $hour, mt_rand(0, 59), mt_rand(0, 59));
                        
                        $storeId = mt_rand(1, 12);
                        
                        // Create order
                        $result = $this->database()->insert('orders')->values([
                            'order_id' => $orderId,
                            'store_id' => $storeId,
                            'customer_id' => mt_rand(1, 100),
                            'order_date' => $orderDate,
                            'total_amount' => 0
                        ])->run();

                        if (!$result) continue;

                        $totalAmount = 0;
                        $itemCount = mt_rand(1, 3);
                        $success = true;
                        
                        // Add order items
                        for ($j = 1; $j <= $itemCount; $j++) {
                            $productId = mt_rand(1, 25);
                            $quantity = mt_rand(1, 3);
                            
                            $product = $this->database()->query(
                                'SELECT base_price FROM products WHERE product_id = ?',
                                [$productId]
                            )->fetch();
                            
                            if (!$product) {
                                $success = false;
                                break;
                            }

                            $unitPrice = (float)$product['base_price'];
                            $lineTotal = $quantity * $unitPrice;
                            $totalAmount += $lineTotal;

                            $orderItemResult = $this->database()->insert('order_items')->values([
                                'order_item_id' => $orderItemId,
                                'order_id' => $orderId,
                                'product_id' => $productId,
                                'quantity' => $quantity,
                                'unit_price' => $unitPrice,
                                'line_total' => $lineTotal
                            ])->run();

                            if (!$orderItemResult) {
                                $success = false;
                                break;
                            }

                            $orderItemId++;
                        }

                        if ($success) {
                            // Update order total
                            $this->database()->update('orders')
                                ->set('total_amount', $totalAmount)
                                ->where('order_id', '=', $orderId)
                                ->run();
                            
                            $totalOrdersCreated++;
                        } else {
                            // Clean up failed order
                            $this->database()->delete('order_items')
                                ->where('order_id', '=', $orderId)
                                ->run();
                            $this->database()->delete('orders')
                                ->where('order_id', '=', $orderId)
                                ->run();
                        }

                        $orderId++;
                    }
                }
            }
            
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function down(): void
    {
        // Delete in reverse order of dependencies
        $this->database()->delete('order_items')->run();
        $this->database()->delete('orders')->run();
        $this->database()->delete('products')->run();
        $this->database()->delete('categories')->run();
        $this->database()->delete('stores')->run();
        $this->database()->delete('regions')->run();
    }
} 