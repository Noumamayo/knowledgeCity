<extends:layout.base title="[[KC Reports Dashboard]]"/>

<stack:push name="styles">
    <link rel="stylesheet" href="/styles/welcome.css"/>
    <style>
        .min-h-screen{
            display: none !important;
        }
        .reports-container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 2rem;
        }
        
        .reports-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            margin-top: 2rem;
        }
        
        .report-card {
            background: #ffffff;
            border-radius: 10px;
            padding: 2rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }
        
        .report-card:hover {
            transform: translateY(-5px);
        }
        
        .report-title {
            font-size: 1.5rem;
            color: #333;
            margin-bottom: 1rem;
        }
        
        .report-description {
            color: #666;
            margin-bottom: 1.5rem;
        }
        
        .report-button {
            display: inline-block;
            padding: 0.8rem 1.5rem;
            background: #2d3748;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.3s ease;
        }
        
        .report-button:hover {
            background: #4a5568;
        }
    </style>
</stack:push>

<define:body>
    <h1 class="main-title">KC Reports Dashboard</h1>

    <div class="reports-container">
        <div class="reports-grid">
            <div class="report-card">
                <h2 class="report-title">Monthly Sales by Region</h2>
                <p class="report-description">
                    View detailed monthly sales data broken down by geographical regions. 
                    Track performance and identify trends across different areas.
                </p>
                <a href="/monthly-sales-by-region" class="report-button">View Report</a>
            </div>

            <div class="report-card">
                <h2 class="report-title">Top Categories by Store</h2>
                <p class="report-description">
                    Analyze the best-performing product categories for each store location. 
                    Identify top sellers and optimize inventory management.
                </p>
                <a href="/top-categories-by-store" class="report-button">View Report</a>
            </div>
        </div>
    </div>

    <div class="version">
        <span>KC Reports System</span>
        <span>PHP @php echo PHP_VERSION; @endphp</span>
    </div>

    <div class="logo">
        <a href="https://www.knowledgecity.com/">
            <img src="https://www.knowledgecity.com/template/images/icons/kc-logo-full.svg" alt="Framework Logotype" width="200px"/>
        </a>
    </div>
</define:body>
